// This file is disabled.
// The project is configured as a Client-Side Vite Application.
// Auth callbacks are handled via client-side redirection to root in App.tsx.
